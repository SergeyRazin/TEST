﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyORMx
{
    [Serializable]
    public class Storage
    {
        public List<Person> L = new List<Person>();
    }
}