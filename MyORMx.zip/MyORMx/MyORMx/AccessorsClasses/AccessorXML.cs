﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace MyORMx.AccessorsClasses
{
    public class AccessorXML:IAccessor
    {
        private Storage storage = new Storage();

        private Storage DesirializXML(string path)
        {
            /*ЕСЛИ XML файл существует , ТО десериализовать его и возврат объекта с данными ИНАЧЕ возврат пустой базы*/

            
            Storage storage = new Storage();
            try
            {
                XmlSerializer xmlserializer = new XmlSerializer(typeof(Storage), new Type[] { typeof(List<Person>) });

                if (File.Exists(path))
                {
                    using (Stream fstream = File.OpenRead(path))
                    {
                        storage = (Storage)xmlserializer.Deserialize(fstream);
                    }
                }
                return storage;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return storage;
            }
        }

        private bool SerializtionWithExchengeFile(string path, Storage база)
        {
            try
            {
                using (Stream fstream = new FileStream(path, FileMode.Create))
                {
                    XmlSerializer xmlserializer = new XmlSerializer(typeof(Storage), new Type[] { typeof(List<Person>) });

                    xmlserializer.Serialize(fstream, база);
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public bool AddPerson(Person p)
        {
            try
            {
                storage = DesirializXML("Serialization_XML.xml");
                
                storage.L.Add(p);

                SerializtionWithExchengeFile("Serialization_XML.xml", storage);
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public bool RemovePerson(string name)
        {
            try
            {
                storage = DesirializXML("Serialization_XML.xml");
                
                for (int i = 0; i < storage.L.Count; i++)
                {
                    if (storage.L.ElementAt(i).Name == name)
                    {
                        storage.L.RemoveAt(i);
                        i--;
                    }
                }

                SerializtionWithExchengeFile("Serialization_XML.xml", storage);

                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public bool InsertPerson(int index, Person p)
        {
            try
            {
                storage = DesirializXML("Serialization_XML.xml");

                storage.L.Insert(index, p);

                SerializtionWithExchengeFile("Serialization_XML.xml", storage);
                
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public List<Person> GetAllPerson()
        {
            try
            {
                 storage = DesirializXML("Serialization_XML.xml");

                if (storage.L.Count == 0)
                {
                    Console.WriteLine("в базе нет записей");
                    return new List<Person>();
                }
                else
                {
                    return storage.L;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return new List<Person>();
            }
        }

        public Person GetPersonByIndex(int i)
        {
            storage = DesirializXML("Serialization_XML.xml");

            if (storage.L.Count == 0)
            {
                return null;
            }
            else 
            {
                try
                {
                    return storage.L[i];
                }
                catch 
                {
                    return new Person() { Name = "такого индекса нет" };
                }
            }
        }

        public int Count()
        {
            storage = DesirializXML("Serialization_XML.xml");

            return storage.L.Count;
            
        }

        public bool Clear()
        {
            if (File.Exists("Serialization_XML.xml"))
            {
                File.Delete("Serialization_XML.xml");
            }
            return true;
        }
    }
}
